// MODULE
var weatherApp = angular.module('weatherApp', ['ngRoute', 'ngResource']);

