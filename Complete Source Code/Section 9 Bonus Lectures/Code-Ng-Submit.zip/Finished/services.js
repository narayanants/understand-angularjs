// SERVICES
weatherApp.service('cityService', function() {
   
    this.city = "New York, NY";
    
});