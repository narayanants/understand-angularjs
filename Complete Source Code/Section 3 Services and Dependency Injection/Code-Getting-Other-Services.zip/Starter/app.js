var myApp = angular.module('myApp', []);

myApp.controller('mainController', function($scope) {
    
});